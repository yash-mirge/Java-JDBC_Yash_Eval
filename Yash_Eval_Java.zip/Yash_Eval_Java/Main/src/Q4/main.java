package Q4;

import java.io.*;

class Student implements Serializable {
    int id;
    String name;

    Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

}

public class main {
public static void main(String[] args) {

ObjectOutputStream oos = new ObjectOutputStream(
new FileOutputStream("student.ser"));
oos.writeObject(new Student(1, "John"));
oos.close();


ObjectInputStream ois = new ObjectInputStream(
new FileInputStream("student.ser"));
Student s = (Student) ois.readObject();
ois.close();

System.out.println(s.id + " " + s.name);

}

}
}
