package Q1;

import java.util.*;

List<String> list = new ArrayList<>();
list.add("Apple");
list.add("Banana");
list.add("Cherry");


for (String item : list) {
    System.out.println(item);
}


Iterator<String> it = list.iterator();
while (it.hasNext()) {
    System.out.println(it.next());
}


Vector<String> vec = new Vector<>(list);
Enumeration<String> en = vec.elements();
while (en.hasMoreElements()) {
    System.out.println(en.nextElement());
}


ListIterator<String> li = list.listIterator();
while (li.hasNext()) {
    System.out.println(li.next());
}







public class Loop {
public static void main(String[] args) {
	
	
	
}
}
