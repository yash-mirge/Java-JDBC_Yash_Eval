package Q23;
class Engine {
    String type;
    Engine(String t) { type = t; }
}

class Car {
    Engine e;
    Car(Engine e) { this.e = e; }
}

public class main {
    public static void main(String[] args) {
        Engine e = new Engine("V8");
        Car c = new Car(e);
        System.out.println(c.e.type);
    }
}
