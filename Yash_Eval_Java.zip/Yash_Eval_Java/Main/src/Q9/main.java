package Q9;

class Emp {
    int id;
    String name;
    double salary;
    String address;

    Emp(int id, String name, double salary, String address) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.address = address;
    }

    public String toString() {
        return "ID: " + id + " Name: " + name +
               " Salary: " + salary + " Address: " + address;
    }
}

public class main {
    public static void main(String[] args) {
        Emp e = new Emp(1, "Yash", 50000, "Mumbai");
        System.out.println(e);
    }
}
