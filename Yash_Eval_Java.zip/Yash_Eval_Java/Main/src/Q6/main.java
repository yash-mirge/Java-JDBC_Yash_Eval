package Q6;
class SharedBox {

    synchronized void produce() throws InterruptedException {
        System.out.println("Produced - now waiting...");
        wait();
        System.out.println("Resumed after notify");
    }

    synchronized void consume() throws InterruptedException {
        Thread.sleep(1000);
        System.out.println("Consuming...");
        notify();
    }
}

public class main {
public static void main(String[] args) {
	SharedBox box = new SharedBox();

	Thread producer = new Thread(() -> {
	    try { box.produce(); } catch (Exception e) {}
	});

	Thread consumer = new Thread(() -> {
	    try { box.consume(); } catch (Exception e) {}
	});

	producer.start();
	consumer.start();

}
}
