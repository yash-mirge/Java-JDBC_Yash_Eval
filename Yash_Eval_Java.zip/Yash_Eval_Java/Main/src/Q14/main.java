package Q14;


class Employee {
    private String name;
    private double salary;
    private int id;

    public String getName() { return name; }
    public double getSalary() { return salary; }
    public int getId() { return id; }

    public void setName(String name) { this.name = name; }
    public void setSalary(double salary) { this.salary = salary; }
    public void setId(int id) { this.id = id; }
}

public class main {
    public static void main(String[] args) {
        Employee e = new Employee();
        e.setName("Alice");
        e.setSalary(60000);
        e.setId(101);

        System.out.println(e.getName() + " " + e.getSalary() + " " + e.getId());
    }
}