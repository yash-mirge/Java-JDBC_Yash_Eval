package Q18;


import java.io.*;

public class main {
    public static void main(String[] args) throws Exception {
        File f = new File("demo.txt");
        f.createNewFile();

        FileWriter w = new FileWriter(f);
        w.write("Hello Java");
        w.close();

        BufferedReader br = new BufferedReader(new FileReader(f));
        System.out.println(br.readLine());
        br.close();

        f.delete();
    }
}

