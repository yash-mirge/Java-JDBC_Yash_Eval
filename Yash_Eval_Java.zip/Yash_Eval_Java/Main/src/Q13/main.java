package Q13;

abstract class Greeting {
    abstract void say();
}

public class main {
    static void display(Greeting g) {
        g.say();
    }

    public static void main(String[] args) {
        Greeting g = new Greeting() {
            void say() {
                System.out.println("Hello from anonymous class");
            }
        };

        display(g);

        display(new Greeting() {
            void say() {
                System.out.println("Hello again!");
            }
        });
    }
}