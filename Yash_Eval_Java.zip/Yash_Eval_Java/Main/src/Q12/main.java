package Q12;
class Animal {
    String type = "Animal";

    Animal() {
        System.out.println("Animal constructor");
    }

    void eat() {
        System.out.println("Animal eating");
    }
}

class Dog extends Animal {
    String type = "Dog";

    Dog() {
        super();
        System.out.println("Dog constructor");
    }

    void show() {
        super.eat();
        System.out.println(super.type);
        System.out.println(this.type);
    }
}

public class main {
    public static void main(String[] args) {
        new Dog().show();
    }
}
