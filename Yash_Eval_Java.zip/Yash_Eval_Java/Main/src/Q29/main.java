package Q29;

class MyThread extends Thread {
    public void run() {
        System.out.println("Thread running");
    }
}

class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Runnable running");
    }
}

public class main {
    public static void main(String[] args) {
        new MyThread().start();
        new Thread(new MyRunnable()).start();
    }
}