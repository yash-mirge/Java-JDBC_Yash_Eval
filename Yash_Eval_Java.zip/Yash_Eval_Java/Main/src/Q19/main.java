package Q19;

class Vehicle {
    Vehicle getInstance() {
        return new Vehicle();
    }
}

class Car extends Vehicle {
    Car getInstance() {
        return new Car();
    }
}

public class main {}