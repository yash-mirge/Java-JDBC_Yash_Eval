package Q27;



class Resource {
    protected void finalize() {
        System.out.println("Cleanup");
    }
}

public class main {
    public static void main(String[] args) {
        Resource r = new Resource();
        r = null;
        System.gc();
    }
}