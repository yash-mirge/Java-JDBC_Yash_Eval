package Q7;

class AgeException extends Exception {
    AgeException(String message) {
        super(message);
    }
}

class AgeValidator {
    static void validate(int age) throws AgeException {
        if (age < 18) {
            throw new AgeException("Age must be 18 or above. Got: " + age);
        }
        System.out.println("Valid age: " + age);
    }
}

public class main {
    public static void main(String[] args) {
        try {
            AgeValidator.validate(15);
        } catch (AgeException e) {
            System.out.println("Caught: " + e.getMessage());
        }
    }
}

