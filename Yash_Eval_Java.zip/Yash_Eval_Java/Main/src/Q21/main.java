package Q21;


public class main {
    public static void main(String[] args) throws Exception {
        System.out.println("Sleeping...");
        Thread.sleep(5000);
        System.out.println("Awake");
    }
}

