package Q22;
class Rectangle {
    int l, w;

    Rectangle(int l, int w) {
        this.l = l;
        this.w = w;
    }

    int area() { return l * w; }
}

public class main {
    public static void main(String[] args) {
        Rectangle r = new Rectangle(10, 5);
        System.out.println(r.area());
    }
}