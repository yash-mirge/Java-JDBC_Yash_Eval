package Q2;
import java.sql.*;

Connection con = DriverManager.getConnection(
"jdbc:mysql://localhost/mydb", "root", " ");


PreparedStatement ps = con.prepareStatement(
"INSERT INTO student VALUES(?, ?, ?)");
ps.setInt(1, 1);
ps.setString(2, "John");
ps.setString(3, "john@mail.com");
ps.executeUpdate();

ps = con.prepareStatement(
"UPDATE student SET name=? WHERE id=?");
ps.setString(1, "Jane");
ps.setInt(2, 1);
ps.executeUpdate();


ps = con.prepareStatement("DELETE FROM student WHERE id=?");
ps.setInt(1, 1);
ps.executeUpdate();


ResultSet rs = con.createStatement()
.executeQuery("SELECT * FROM student");

while (rs.next()) {
    System.out.println(rs.getInt(1) + " " + rs.getString(2));
}


public class main {
public static void main(String[] args) {
	
}
}
