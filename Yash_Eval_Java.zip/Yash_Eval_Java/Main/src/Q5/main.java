package Q5;



import java.util.*;

class Student implements Comparable<Student> {
    String name;
    int marks;

    Student(String name, int marks) {
        this.name = name;
        this.marks = marks;
    }

    @Override
    public int compareTo(Student other) {
        return this.marks - other.marks;
    }

    public String toString() {
        return name + ":" + marks;
    }
}
public class main {
public static void main(String[] args) {

List<Student> list = new ArrayList<>();
list.add(new Student("Alice", 80));
list.add(new Student("Bob", 70));
list.add(new Student("Carol", 90));

Collections.sort(list);
System.out.println(list);

list.sort(Comparator.comparing(s -> s.name));
System.out.println(list);

}
}
